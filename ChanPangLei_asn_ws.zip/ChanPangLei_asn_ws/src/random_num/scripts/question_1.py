#!/usr/bin/env python

import rospy
from std_msgs.msg import String
import random

def talker():
	rospy.init_node('publisher_node', anonymous = True)
	pub = rospy.Publisher('random_num', String, queue_size=10)
	rate = rospy.Rate(1)

	while not rospy.is_shutdown():
		value = random.randint(1, 1001)
		if (value>500):
			type = "over 500"
		elif (value == 500):
			type = "equal to 500"
		else:
			type = "less than 500"
		#msg = "The number generated is "+type+": "+str(value)+""
		rospy.loginfo("The number generated is "+type+": "+str(value)+"")
		#pub.publish(msg)
		rate.sleep()

if __name__ == '__main__':
	try:
		talker()
	except rospy.ROSInterruptException:
		pass
