#!/usr/bin/env python

import rospy
from std_msgs.msg import UInt16

def talker():
    i = 10
    rospy.init_node('sub', anonymous=True)
    pub = rospy.Publisher('servo', UInt16, queue_size=10)
    rate = rospy.Rate(1)

    while not rospy.is_shutdown():
        for i in range (10, 171, 20):
            #rospy.loginfo("Data sent")
            pub.publish(i)
            rate.sleep()
            print(i)
        if i == 170:
            #print("ok")
            for i in range (170, 10, -20):
                pub.publish(i)
                rate.sleep()
                print(i)

if __name__ == '__main__':
	try:
		talker()
	except rospy.ROSInterruptException:
		pass
